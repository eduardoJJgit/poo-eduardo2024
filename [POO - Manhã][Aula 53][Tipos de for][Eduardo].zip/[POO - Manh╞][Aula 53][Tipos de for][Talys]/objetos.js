let timeA = {
    nome: 'São Paulo',
    anoDaFundacao: 1930,
    estadoDeOrigem: 'São Paulo',
    escudo: 'saoPaulo.jpg'
}

let timeB = {
    nome: 'Vasco da Gama',
    anoDaFundacao: 1898,
    estadoDeOrigem: 'Rio de Janeiro',
    escudo: 'vasco.jpg'
}

let timeC = {
    nome: 'Atlético Mineiro',
    anoDaFundacao: 1908,
    estadoDeOrigem: 'Minas Gerais',
    escudo: 'mg.png'
}

let timeD = {
    nome: 'CSA',
    anoDaFundacao: 1913,
    estadoDeOrigem: 'Alagoas',
    escudo: 'csa.png'
}


let timeE = {
    nome:'Internacional FC',
    anoDaFundacao: 1909,
    estadoDeOrigem: 'Rio Grande Sul',
    escudo: 'inter.png'
}

let time =[]

time.push(timeA)
time.push(timeB)
time.push(timeC)
time.push(timeD)
time.push(timeE)

