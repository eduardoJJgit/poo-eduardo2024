let containerCards = document.getElementById("containerCards")
let iptNome = document.getElementById("iptNome")
let iptEstado = document.getElementById("iptEstado")
let iptAno = document.getElementById("iptAno")
let iptEscudo = document.getElementById("iptEscudo")
let btnCadastrar = document.getElementById("btnCadastrar")

desenharCards(containerCards,time)


let srcImagem;

function quandoCarregarArquivo(){
    const fileReader = new FileReader();
    const arquivos = iptEscudo.files;

    if(arquivos .length > 0){
        fileReader.onload = function (event){
            srcImagem = event.target.result;
        }
        fileReader.readAsDataURL(arquivos[0]);
    }
}

iptEscudo.addEventListener('change', quandoCarregarArquivo);


function cadastra(){

    let timeTemp = {
        nome: iptNome.value,
        anoDaFundacao: iptAno.value,
        estadoDeOrigem: iptEstado.value,
        escudo: srcImagem
    }

    time.push(timeTemp)

    desenharCards(containerCards, time)
}
  
btnCadastrar.addEventListener("click", cadastra)