let containerCards = document.getElementById('containerCards');

desenharCards(containerCards, listaDeTimes);