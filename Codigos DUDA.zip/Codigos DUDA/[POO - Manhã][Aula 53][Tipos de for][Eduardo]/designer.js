function desenharCards(tagContainerCards, listaDeTimes){
    tagContainerCards.innerHTML = '';

    for (const time of listaDeTimes) {
        tagContainerCards.innerHTML  +=`
        <div class="card">
             <img class="escudo" src="img/${time.fotoEscudo}">
             <span class="titulo">${time.nome}</span>
             <span class="texto">${time.estadoDeOrigem}</span>
             <span class="texto">${time.anoDaFundacao}</span>
        </div>
        `;
    }
}