let timeA = {
    nome: 'Corinthias',
    anoDaFundacao: 1910,
    estadoDeOrigem: 'São Paulo',
    fotoEscudo: 'corinthians.svg'
}

let timeB = {
    nome: 'Real madrid',
    anoDaFundacao: 1902,
    estadoDeOrigem: 'Madrid',
    fotoEscudo: 'real-madrid.svg'
}

let timeC = {
    nome: 'Barcelona',
    anoDaFundacao: 1899,
    estadoDeOrigem: 'Barcelona',
    fotoEscudo: 'barcelona.svg'
}

let timeD = {
    nome: 'manchester united',
    anoDaFundacao: 1878,
    estadoDeOrigem: 'Manchester',
    fotoEscudo: 'Manchester_United.svg'
}

let timeE = {
    nome: 'Manchester City',
    anoDaFundacao: 1880,
    estadoDeOrigem: 'Manchester',
    fotoEscudo: 'Manchester_City.svg'
}

let listaDeTimes = [];
listaDeTimes.push(timeA);
listaDeTimes.push(timeB);
listaDeTimes.push(timeC);
listaDeTimes.push(timeD);
listaDeTimes.push(timeE);